<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'bbb';

// Create a connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}else{
    die("its working");
}

// Rest of your code...